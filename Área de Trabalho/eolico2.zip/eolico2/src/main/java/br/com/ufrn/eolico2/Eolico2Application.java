package br.com.ufrn.eolico2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Eolico2Application {

	public static void main(String[] args) {
		SpringApplication.run(Eolico2Application.class, args);
	}

}
