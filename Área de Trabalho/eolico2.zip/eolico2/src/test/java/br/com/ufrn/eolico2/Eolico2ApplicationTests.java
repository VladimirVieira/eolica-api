package br.com.ufrn.eolico2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Eolico2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
