package br.com.ufrn.eolico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EolicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
