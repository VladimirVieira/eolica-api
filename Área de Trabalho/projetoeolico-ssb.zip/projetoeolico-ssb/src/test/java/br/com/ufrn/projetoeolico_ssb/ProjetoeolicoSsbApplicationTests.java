package br.com.ufrn.projetoeolico_ssb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoeolicoSsbApplicationTests {

	@Test
	void contextLoads() {
	}

}
