package br.com.ufrn.projetoeolico_ssb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoeolicoSsbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoeolicoSsbApplication.class, args);
	}

}
