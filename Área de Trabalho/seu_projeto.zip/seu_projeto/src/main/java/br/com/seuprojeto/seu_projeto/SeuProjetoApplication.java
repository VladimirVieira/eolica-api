package br.com.seuprojeto.seu_projeto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeuProjetoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeuProjetoApplication.class, args);
	}

}
