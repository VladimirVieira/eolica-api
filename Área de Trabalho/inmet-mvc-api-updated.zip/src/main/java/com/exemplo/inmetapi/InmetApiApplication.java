package com.exemplo.inmetapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InmetApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(InmetApiApplication.class, args);
    }
}