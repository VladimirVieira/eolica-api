package batalha;

class PersonagemTest {
}
