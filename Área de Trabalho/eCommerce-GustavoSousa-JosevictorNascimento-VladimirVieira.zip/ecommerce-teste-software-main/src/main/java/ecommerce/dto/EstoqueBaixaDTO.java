package ecommerce.dto;

public record EstoqueBaixaDTO(Boolean sucesso) {

}
