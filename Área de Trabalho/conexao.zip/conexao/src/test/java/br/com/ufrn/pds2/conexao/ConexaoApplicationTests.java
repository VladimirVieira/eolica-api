package br.com.ufrn.pds2.conexao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConexaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
