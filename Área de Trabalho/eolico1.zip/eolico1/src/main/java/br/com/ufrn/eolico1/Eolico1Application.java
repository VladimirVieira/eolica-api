package br.com.ufrn.eolico1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Eolico1Application {

	public static void main(String[] args) {
		SpringApplication.run(Eolico1Application.class, args);
	}

}
