# Executando a API via terminal:

## 1. Para compilar:
   
    ./mvnw clean install

## 2. Para iniciar a API:

    ./mvnw spring-boot:run


## Para visualizar funcionando, você deve abrir o seu navegador e digitar:

    http://localhost:8080
