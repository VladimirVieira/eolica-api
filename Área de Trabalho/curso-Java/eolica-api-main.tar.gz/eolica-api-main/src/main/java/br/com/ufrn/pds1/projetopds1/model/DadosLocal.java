package br.com.ufrn.pds1.projetopds1.model;

public class DadosLocal {
	private double temperatura;
	private double velVento;
	private double latitude;
	private double longitude;
	private String data;
	
	public double getTemperatura() {
		return temperatura;
	}
	public void setTemperatura(double temperatura) {
		this.temperatura = temperatura;
	}
	public double getVelVento() {
		return velVento;
	}
	public void setVelVento(double velVento) {
		this.velVento = velVento;
	}
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
	
}
