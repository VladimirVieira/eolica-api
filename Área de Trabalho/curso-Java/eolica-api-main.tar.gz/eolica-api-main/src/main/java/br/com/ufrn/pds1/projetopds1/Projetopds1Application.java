package br.com.ufrn.pds1.projetopds1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projetopds1Application {

	public static void main(String[] args) {
		SpringApplication.run(Projetopds1Application.class, args);
	}

}
