package br.com.ufrn.pds1.projetopds1.service;

public class DadosDiarioClimaUrbano {

}
