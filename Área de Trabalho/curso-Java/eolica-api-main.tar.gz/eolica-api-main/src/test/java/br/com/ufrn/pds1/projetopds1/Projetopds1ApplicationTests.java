package br.com.ufrn.pds1.projetopds1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projetopds1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
