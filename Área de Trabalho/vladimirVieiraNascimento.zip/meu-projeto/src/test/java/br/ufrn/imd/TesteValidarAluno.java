package br.ufrn.imd;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class TesteValidarAluno {
	 private Discente discente;
	    private Docente docente;
	    private Disciplina disciplina;
	    private Turma turma;
	    private Matricula matricula;

	    @BeforeEach
	    public void setup() {
	        discente = new Discente();
	        discente.setNome("Aluno");
	        discente.setMatricula(1);
	        
	        docente = new Docente();
	        docente.setNome("Professor");
	        docente.setSiape(2);
	        
	        disciplina = new Disciplina();
	        disciplina.setNome("Disciplina");
	        disciplina.setCodigo("IMD001)");
	        
	        turma = new Turma(docente, disciplina);
	        matricula = new Matricula(discente, turma);
	    }

	    @ParameterizedTest
	    @CsvSource(value = {
	        "7.2: 7.4: 7.77: 76: APR",
	        "6.5: 7.2: 8.8: 85: APR",
	        "9.0: 9.0: 2.5: 90: REC",
	        "4.1: 3.1: 5.0: 80: REC",
	        "9.3: 2.0:  3.0: 85: REC",
	        "5.0: 5.0: 7.0: 65: REPF",
	        "3.0: 3.0: 4.0: 74: REPF",
	        "2.0: 2.0: 4.0: 50: REPMF"
	    }, delimiter = ':')
	    void testCalculoMediaParcial(BigDecimal nota1, BigDecimal nota2, BigDecimal nota3, Integer frequencia, StatusAprovacao statusEsperado) {
	        
	    	// Arrange
	    	matricula.cadastrarFrequencia(frequencia);
	        matricula.cadastrarNota1(nota1);
	        matricula.cadastrarNota2(nota2);
	        matricula.cadastrarNota3(nota3);
	        
	        // Act
	        matricula.consolidarParcialmente();
	        
	        // Assert
	        StatusAprovacao statusRetornado = matricula.getStatus();
	        assertEquals(statusEsperado, statusRetornado);
    
    
	    }
}
