package br.ufrn.imd;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Matricula {
	private final Discente discente;
	
	private final Turma turma;
	
	private BigDecimal nota1;

	private BigDecimal nota2;

	private BigDecimal nota3;

	private Integer frequencia;
	
	private StatusAprovacao status;

	Matricula(Discente discente, Turma turma) {
		this.discente = discente;
		this.turma = turma;
	}

	public BigDecimal getNota1() {
		return nota1;
	}

	public void cadastrarNota1(BigDecimal nota1) {
		this.nota1 = nota1;
	}

	public BigDecimal getNota2() {
		return nota2;
	}

	public void cadastrarNota2(BigDecimal nota2) {
		this.nota2 = nota2;
	}

	public BigDecimal getNota3() {
		return nota3;
	}

	public void cadastrarNota3(BigDecimal nota3) {
		this.nota3 = nota3;
	}

	public Integer getFrequencia() {
		return frequencia;
	}

	public void cadastrarFrequencia(Integer frequencia) {
		this.frequencia = frequencia;
	}

	public Discente getDiscente() {
		return discente;
	}

	public Turma getTurma() {
		return turma;
	}

	public void consolidarParcialmente() {
		// TODO Implementar aqui a lógica de consolidação parcial
        
        
        BigDecimal media3 = BigDecimal.valueOf(3);
        BigDecimal media6 = BigDecimal.valueOf(6);
        BigDecimal mediaParcial = nota1.add(nota2).add(nota3).divide(BigDecimal.valueOf(3), RoundingMode.HALF_UP);
        // BigDecimal mediaParcial = nota1.add(nota2).add(nota3).divide(new BigDecimal ("3"));
		
        
        
    
        // Verificar frequência
        if (frequencia.compareTo(75)<0) {
        	//Verificar média
        	if(mediaParcial.compareTo(media3) < 0) {
        		this.setStatus(StatusAprovacao.REPMF);
        		
        	} else if(mediaParcial.compareTo(media3) > 0) {
        		this.setStatus(StatusAprovacao.REPF);
        	
        	}
        	
        } else {
        	// Verificar notas
            if (mediaParcial.compareTo(media3) < 0) {
            	this.setStatus(StatusAprovacao.REP);
            	
            } else if (mediaParcial.compareTo(media6) >= 0){
            	
            	if(nota1.compareTo(BigDecimal.valueOf(4)) >= 0 &&
                nota2.compareTo(BigDecimal.valueOf(4)) >= 0 &&
                nota3.compareTo(BigDecimal.valueOf(4)) >= 0) {
            		this.setStatus(StatusAprovacao.APR);
            		
            	} else {
            		
            		this.setStatus(StatusAprovacao.REC);
            	}
            	
            } else if (mediaParcial.compareTo(media3) >= 0 && 
                    mediaParcial.compareTo(media6) < 0){
            	this.setStatus(StatusAprovacao.REC);
             
            }else{
        		this.setStatus(StatusAprovacao.REPF);
        		
        	}
     
        }
           
	}

	public StatusAprovacao getStatus() {
		return status;
	}

	private void setStatus(StatusAprovacao status) {
		this.status = status;
	}
}