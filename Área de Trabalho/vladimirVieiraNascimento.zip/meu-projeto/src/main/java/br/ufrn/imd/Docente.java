package br.ufrn.imd;

public class Docente {
	private String nome;
	
	private Integer siape;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Integer getSiape() {
		return siape;
	}

	public void setSiape(Integer siape) {
		this.siape = siape;
	} 
}
